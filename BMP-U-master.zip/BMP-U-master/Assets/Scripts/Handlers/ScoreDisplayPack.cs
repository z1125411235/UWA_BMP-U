﻿using UnityEngine;

public class ScoreDisplayPack:ScriptableObject {
    public Sprite[] images;
}
