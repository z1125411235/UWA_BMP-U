﻿using UnityEngine;

class AutoHide: MonoBehaviour {
    void Start() {
        gameObject.SetActive(false);
    }
}
